
import React from 'react';

function App() {
  return (
    <main style={{ minHeight: '100vh', backgroundColor: '#0f0f0f', color: '#fff', padding: '2rem' }}>
      <header style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>Onika Javu</h1>
        <p style={{ fontSize: '1.25rem', color: '#aaa' }}>Full-Stack Developer</p>
      </header>
      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>About Me</h2>
        <p style={{ color: '#ccc', maxWidth: '600px', margin: '1rem auto' }}>
          I'm a developer with a passion for dynamic and complex web applications and solving real-world problems through code.
        </p>
      </section>
      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>Skills</h2>
        <ul style={{ columns: 2, maxWidth: '600px', margin: '1rem auto', color: '#ccc' }}>
          <li>JavaScript</li>
          <li>React</li>
          <li>Node.js</li>
          <li>HTML & CSS</li>
          <li>Python</li>
          <li>SQL</li>
          <li>Git & GitHub</li>
          <li>REST APIs</li>
          <li>MongoDB</li>
          <li>Express.js</li>
          <li>Java</li>
          <li>Data Structures & Algorithms</li>
          <li>Linux/Unix Basics</li>
          <li>Docker (basics)</li>
        </ul>
      </section>
      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>Projects</h2>
        <p style={{ color: '#888' }}>Coming soon...</p>
      </section>
      <section style={{ marginBottom: '2rem' }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>Resume</h2>
        <p style={{ color: '#888' }}>Will be added later.</p>
      </section>
      <section>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '600' }}>Contact</h2>
        <p style={{ color: '#888' }}>Coming soon...</p>
      </section>
      <footer style={{ marginTop: '3rem', textAlign: 'center', fontSize: '0.875rem', color: '#555' }}>
        © {new Date().getFullYear()} Onika Javu. All rights reserved.
      </footer>
    </main>
  );
}

export default App;
